from py4j.java_gateway import JavaGateway

gateway = JavaGateway()

password = "toto"
encrrypt = "h7BWig==$0KcgcInEf1WhNDEp9YhLyKCZGcL1Fcv2llj900YoeO4="
boule = gateway.check(password,encrrypt)
print "password: ", password
print "encrypted: ", encrrypt
print(boule)
