#!/usr/bin/python
from subprocess import call
import os
import MySQLdb

# Open a file
fo = open("toto.txt", "rw+")
print "Name of the file: ", fo.name

#
# ajouter une boucle qui passe au travers du fichier
# jusqua la fin du fichier
# with open(...) as f:
#    for line in f:
#        <do something with line>
#

i = 11
defaultuser = 'pierrot' + str(i)

with open("toto.txt", "rw+") as oldusers:
   for line in oldusers:
      print "Read Line: %s" % (line)

      myLine = line.split()

      print "USER_ID is :", myLine[0]
      print "EMAIL is :", myLine[1]
      print "EMAILLC is :", myLine[2]
      print "FIRST_NAME is :", myLine[3]
      print "LAST_NAME is :", myLine[4]
      print "TYPE is :", myLine[5]
      print "PW is :", myLine[6]
      print "CREATEDBY is :", myLine[7]
      print "MODIFIEDBY is :", myLine[8]
      print "CREATEDON is :", myLine[9]
      print "MODIFIEDON is :", myLine[10]

      salt, password = myLine[6].split(':', 2)
      newpassword = "sakai$1$" + salt + '$' + password

      print "salt is: :", salt
      print "password is :", password
      print "new password is :", newpassword

      defaultuser = 'pierrot' + str(i)
      i = i + 1

      #
      # creation un usager
      # voir comment ajouter le cours avec une variable
      # voir quoi utiliser comme username
      #
      command = "cd /edx/app/edxapp/edx-platform ; sudo -u www-data /edx/bin/python.edxapp ./manage.py lms --settings aws create_user --name='%s' --email='%s' --username='%s' --course='%s'" % (myLine[3] + ' ' +  myLine[4], myLine[1], defaultuser, 'edX/Open_DemoX/edx_demo_course')
      print command
      p = os.system (command)

      #
      # connect to mysql
      #
      db = MySQLdb.connect(host="localhost", user="edxapp001", passwd="password", db="edxapp")

      cursor = db.cursor()

      #
      # execute SQL select statement
      #
      cursor.execute("SELECT * FROM auth_user")

      #
      # voir comment mettre le username
      #
      cursor.execute("UPDATE auth_user SET password=%s WHERE username=%s", (newpassword, defaultuser));
      cursor.execute("UPDATE auth_user SET first_name=%s,last_name=%s WHERE username=%s", (myLine[3], myLine[4], defaultuser));

      #
      # commit your changes
      #
      db.commit()

#  select * from auth_user ;
#| id | username           | first_name | last_name     | email                           | password                                                                      | is_staff | is_active | is_superuser | last_login          | date_joined         |
#| 37 | pierrot2           | Pierrot2   | Mailhot       | pierrot2@udm.ca                 | sakai$1$mlNxcQ==$8zAj/jnsuzmaiCLua9MElPKQd7tg8KFLr0Kzo+rAdJA=                 |        0 |         1 |            0 | 2014-12-22 23:40:01 | 2014-12-22 23:40:01 |


# select * from auth_registration ;
#| id | user_id | activation_key                   
#| 34 |      37 | 7e81ec0ab8f54b8c975d6a78781fc02e


# select * from auth_userprofile ;
#| id | user_id | name                 | language | location | meta | courseware | gender | mailing_address                                         | year_of_birth | level_of_education | goals | allow_certificate | country | city |
#| 34 |      37 | Pierrot2 Mailhot     |          |          |      | course.xml | NULL   | NULL                                                    |          NULL | NULL               | NULL  |                 1 |         | NULL |


# select * from user_api_userpreference ;
#| id | user_id | key       | value |
#| 34 |      37 | pref-lang | fr    |


# select * from student_courseenrollment ;
#| id | user_id | course_id                                 | created             | is_active | mode     |
#| 47 |      36 | edX/Open_DemoX/edx_demo_course            | 2014-12-22 23:20:57 |         1 | honor    |


# select * from user_api_usercoursetag 
#| id | user_id | key                                             | course_id                             | value        |
#|  1 |       7 | xblock.partition_service.partition_603994846769 | UniversiteDeMontreal/devel-ccedx/A14  | 490442546267 |
#|  2 |       9 | xblock.partition_service.partition_202035149404 | UniversiteDeMontreal/devel-ccedx3/A14 | 539408412316 |
#|  6 |      18 | xblock.partition_service.partition_350548817744 | UniversiteDeMontreal/devel-ccedx3/A14 | 740774733496 |
#|  7 |      18 | xblock.partition_service.partition_823011199724 | UniversiteDeMontreal/devel-ccedx3/A14 | 97579076434  |


# select * from certificates_generatedcertificate ;
#| id | user_id | download_url                                                                                             | grade | course_id                      | key                              | distinction | status       | verify_uuid                      | download_uuid                    | name  | created_date        | modified_date       | error_reason                                                                                                                             | mode  |
#|  1 |       1 | https://edulib-xqueue-bucket.s3.amazonaws.com/downloads/835f7fafd8074128a49905654d8fa05d/Certificate.pdf | 0.0   | edX/Open_DemoX/edx_demo_course | 63313c329270d4ab5a124b80199e5218 |           0 | downloadable | a772db0dec764ee9a627f276c29f79fd | 835f7fafd8074128a49905654d8fa05d | honor | 2014-12-13 01:43:29 | 2014-12-17 18:51:04 | (honor edX/Open_DemoX/edx_demo_course) <type 'exceptions.OSError'>: [Errno 13] Permission denied: 'downloads' : certificate_agent.py:101 | honor |

